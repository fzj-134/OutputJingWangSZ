﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Runtime.InteropServices;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;

using Pub;

//[Fault]
//shift =
//date =
//daystart =
//dayshift =
//fault =
//actrun =
//[Path]
//Data =
//Signal =
//Password =
//User =
//Picture = D:\AoiImage
//wat=
//upwat=

namespace OutputJingWangSZ
{

	public partial class DlgMain : Form
	{
        #region 加载预处理
        /// <summary>
        /// 记录文件
        /// </summary>
        private IniFiles timeIni { get; set; }

        /// <summary>
        /// oew.ini
        /// </summary>
        private IniFiles oewIni { get; set; } = new IniFiles("D:\\LinkMaster\\oew.ini");

        /// <summary>
        /// 目录，D:\Output\
        /// </summary>
        private string outPath { get; set; }

        /// <summary>
        /// oew.ini相应的信息
        /// </summary>
        private OewiniClass oewiniclass = new OewiniClass();

        /// <summary>
        /// D:\Picture信息
        /// </summary>
        private List<FileDirectoryClass> fdcs = new List<FileDirectoryClass>();
        
        public DlgMain()
		{
			InitializeComponent();
            this.Load += DlgMain_Load;
        }

        private void DlgMain_Load(object sender, EventArgs e) => M_Load();

        private void M_Load()
        {
            try
            {
                //this.WindowState = FormWindowState.Minimized;
                lblVersion2.Text = System.Windows.Forms.Application.ProductVersion;
                outPath = oewIni.ReadPath("General", "OutputPath", @"D:\Output\");
                if (!File.Exists(outPath + "Time.ini"))
                {
                    File.Create(outPath + "Time.ini");
                }
                timeIni = new IniFiles(outPath + "Time.ini");
                textBoxpath.Text = timeIni.ReadString("Path", "Picture", string.Empty);
                if (string.IsNullOrEmpty(textBoxpath.Text))
                    textBoxpath.SetWatermark("请点击浏览按钮选择目录....");
                OewiniClass.OewiniClassSetting(ref oewiniclass, oewIni);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

        #endregion

        #region 执行上传，选择目录，刷新界面
        /// <summary>
        /// 选择目录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonpath_Click(object sender, EventArgs e)
        {
            if (fbDlg1.ShowDialog(this) == DialogResult.OK)
                textBoxpath.Text = fbDlg1.SelectedPath;
            if (textBoxpath.Text != timeIni.ReadString("Path", "Picture", string.Empty))
                timeIni.WriteString("Path", "Picture", textBoxpath.Text);
        }

        public async void method_update() => await Task.Run(new Action(S_update));

        private void S_update()
        {
            Enabled_TF(false);
            try
            {
                List<FileDirectoryClass> objv = new List<FileDirectoryClass>();
                Exception Ex_me = null;
                FileDirectoryClass.GetFiles(ref objv, ref Ex_me, oewiniclass.CapturePath);
                if (Ex_me == null)
                {
                    if (Return_bool(objv, fdcs))
                    {
                        objv.Clear();
                        foreach (DataGridViewRow v in dataGridView_pic.Rows)
                        {
                            if (v.Cells["Column_Choice"].Value.ToString() == 1.ToString())
                            {
                                var a = fdcs.Where(e => e.Item_No == v.Cells["Column_Item_no"].Value.ToString() && e.file_time.ToString() == v.Cells["Column_time"].Value.ToString() && e.Aoi_No == v.Cells["Column_AOI"].Value.ToString() && v.Cells["Column_Eff"].Value.ToString() == "是").FirstOrDefault();
                                if (a != null)
                                {
                                    objv.Add(a);
                                }
                            }
                        }
                        if (objv.Count() > 0)
                        {
                            List<OutputClass> outputs = new List<OutputClass>();
                            OutputClass.GetOutput(ref outputs, objv, textBoxpath.Text);
                            if (!string.IsNullOrEmpty(textBoxpath.Text) && Directory.Exists(textBoxpath.Text))
                            {
                                OutputClass.SetOutput(outputs, textBoxpath.Text);
                                Hint_Text("上传成功！");
                            }
                            else
                            {
                                Hint_Text("请设置有效目录！");
                            }
                        }
                        else
                        {
                            Hint_Text("没有选择内容，请点击刷新按钮，后单击选择！");
                        }
                    }
                    else
                    {
                        Hint_Text("选择内容过时，请点击刷新按钮！");
                    }
                }
                else
                {
                    Hint_Text(Ex_me.Message);
                }
            }
            catch (Exception ex)
            {
                Hint_Text(ex.Message);
            }
            Enabled_TF(true);
            buttonChoice_Click(null, null);
        }

        /// <summary>
        /// 上传图片按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonupdate_Click(object sender, EventArgs e)
        {
            method_update();
        }

        private bool Return_bool(List<FileDirectoryClass> obj1, List<FileDirectoryClass> obj2)
        {
            if (obj1.Count() != obj2.Count())
            {
                return false;
            }
            for(int i=0;i< obj1.Count(); i++)
            {
                if (obj1[i].Mach_No != obj2[i].Mach_No)
                {
                    return false;
                }
                if (obj1[i].CapturePath != obj2[i].CapturePath)
                {
                    return false;
                }
                if (obj1[i].Aoi_No != obj2[i].Aoi_No)
                {
                    return false;
                }
                if (obj1[i].Item_No != obj2[i].Item_No)
                {
                    return false;
                }
                if (obj1[i].FileDirectory != obj2[i].FileDirectory)
                {
                    return false;
                }
                if (obj1[i].file_time != obj2[i].file_time)
                {
                    return false;
                }
                if (obj1[i].pictures.Count() != obj2[i].pictures.Count())
                {
                    return false;
                }
                for (int k = 0; k < obj1[i].pictures.Count(); k++)
                {
                    if (obj1[i].pictures[k].Layer != obj2[i].pictures[k].Layer)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].Level != obj2[i].pictures[k].Level)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].Lot_No != obj2[i].pictures[k].Lot_No)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].Board_Id != obj2[i].pictures[k].Board_Id)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].Shortcoming != obj2[i].pictures[k].Shortcoming)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].Aoi_Code != obj2[i].pictures[k].Aoi_Code)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].Vrs_Code != obj2[i].pictures[k].Vrs_Code)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].FileFullName != obj2[i].pictures[k].FileFullName)
                    {
                        return false;
                    }
                    if (obj1[i].pictures[k].FileName != obj2[i].pictures[k].FileName)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public async void method_Choice() => await Task.Run(new Action(S_Choice));

        private void S_Choice()
        {
            Enabled_TF(false);
            dataGridView_pic.Rows.Clear();
            fdcs.Clear();
            try
            {
                Exception Ex_me = null;
                FileDirectoryClass.GetFiles(ref fdcs, ref Ex_me, oewiniclass.CapturePath);
                if (Ex_me == null)
                {
                    foreach (var a in fdcs)
                    {
                        if (a.pictures.Count() > 0)
                        {
                            dataGridView_pic.Rows.Add(new object[] { false, a.Item_No, a.Aoi_No, "是", a.file_time });
                        }
                        else
                        {
                            dataGridView_pic.Rows.Add(new object[] { false, a.Item_No, a.Aoi_No, "否", a.file_time });
                        }
                    }
                    Hint_Text("刷新数据成功！");
                }
                else
                {
                    Hint_Text(Ex_me.Message);
                }
            }
            catch (Exception ex)
            {
                Hint_Text(ex.Message);
            }
            Enabled_TF(true);
        }

        /// <summary>
        /// 刷新界面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonChoice_Click(object sender, EventArgs e)
        {
            method_Choice();
        }

        private void Hint_Text(string str)
        {
            str = str.Replace("\r\n", string.Empty);
            textBox_hint.AppendText("\r\n" + str + DateTime.Now.ToString());
        }

        private void Enabled_TF(bool tf)
        {
            buttondelect.Enabled = tf;
            buttonupdate.Enabled = tf;
            buttonpath.Enabled = tf;
            buttonChoice.Enabled = tf;
            dataGridView_pic.Enabled = tf;
        }

        private void dataGridView_pic_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dataGridView_pic.Rows[e.RowIndex].Cells["Column_Choice"].Value.ToString() == 1.ToString())
                this.dataGridView_pic.Rows[e.RowIndex].Cells["Column_Choice"].Value = 0;
            else
                this.dataGridView_pic.Rows[e.RowIndex].Cells["Column_Choice"].Value = 1;
        }

        private void buttondelect_Click(object sender, EventArgs e)
        {
            method_Delect();
        }

        public async void method_Delect() => await Task.Run(new Action(S_Delect));

        private void S_Delect()
        {
            Enabled_TF(false);
            try
            {
                List<FileDirectoryClass> objv = new List<FileDirectoryClass>();
                Exception Ex_me = null;
                FileDirectoryClass.GetFiles(ref objv, ref Ex_me, oewiniclass.CapturePath);
                if (Ex_me == null)
                {
                    if (Return_bool(objv, fdcs))
                    {
                        objv.Clear();
                        foreach (DataGridViewRow v in dataGridView_pic.Rows)
                        {
                            if (v.Cells["Column_Choice"].Value.ToString() == 1.ToString())
                            {
                                //var a = fdcs.Where(e => e.Item_No == v.Cells["Column_Item_no"].Value.ToString() && e.file_time.ToString() == v.Cells["Column_time"].Value.ToString() && e.Aoi_No == v.Cells["Column_AOI"].Value.ToString() && v.Cells["Column_Eff"].Value.ToString() == "否").FirstOrDefault();
                                var a = fdcs.Where(e => e.Item_No == v.Cells["Column_Item_no"].Value.ToString() && e.file_time.ToString() == v.Cells["Column_time"].Value.ToString() && e.Aoi_No == v.Cells["Column_AOI"].Value.ToString()).FirstOrDefault();
                                if (a != null)
                                {
                                    objv.Add(a);
                                }
                            }
                        }
                        if (objv.Count() > 0)
                        {
                            foreach (var r in objv)
                            {
                                if (Directory.Exists(r.FileDirectory))
                                {
                                    var va = new DirectoryInfo(r.FileDirectory);
                                    foreach (var f in va.GetFiles())
                                    {
                                        if (File.Exists(f.FullName))
                                        {
                                            File.Delete(f.FullName);
                                        }
                                    }
                                    Directory.Delete(r.FileDirectory);
                                }
                            }
                            Hint_Text("删除成功！");
                        }
                        else
                        {
                            Hint_Text("没有选择内容，请点击刷新按钮，后单击选择！");
                        }
                    }
                    else
                    {
                        Hint_Text("选择内容过时，请点击刷新按钮！");
                    }
                }
                else
                {
                    Hint_Text(Ex_me.Message);
                }
            }
            catch (Exception ex)
            {
                Hint_Text(ex.Message);
            }
            Enabled_TF(true);
            buttonChoice_Click(null, null);
        }
        #endregion

        #region 界面设置
        /// <summary>
        /// 添加双击托盘图标事件（双击显示窗口）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //还原窗体显示    
                WindowState = FormWindowState.Normal;
                //激活窗体并给予它焦点
                this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                NotifyIcon.Visible = false;
            }
        }
        /// <summary>
        /// 判断是否最小化,然后显示托盘
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DlgMain_SizeChanged(object sender, EventArgs e)
        {
            ////判断是否选择的是最小化按钮
            //if (WindowState == FormWindowState.Minimized)
            //{
            //    //隐藏任务栏区图标
            //    this.ShowInTaskbar = false;
            //    //图标显示在托盘区
            //    NotifyIcon.Visible = true;
            //}
        }
        /// <summary>
        /// 确认是否退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DlgMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("是否确认退出程序？", "退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                // 关闭所有的线程
                this.Dispose();
                this.Close();
            }
            else
            {
                e.Cancel = true;
            }
        }
        /// <summary>
        /// 托盘右键显示主界面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 显示ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //还原窗体显示    
                WindowState = FormWindowState.Normal;
                //激活窗体并给予它焦点
                this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                NotifyIcon.Visible = false;
            }
        }
        /// <summary>
        /// 托盘右键退出程序
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("是否确认退出程序？", "退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                // 关闭所有的线程
                this.Dispose();
                this.Close();
            }
        }

        #endregion
    }

    #region 基于.NET 2.0的TextBox工具类
    /// <summary>
    /// 基于.NET 2.0的TextBox工具类
    /// </summary>
    public static class TextBoxToolV2
    {
        private const int EM_SETCUEBANNER = 0x1501;
        [DllImport("user32.dll", CharSet = CharSet.Auto)]

        private static extern Int32 SendMessage
         (IntPtr hWnd, int msg, int wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);

        /// <summary>
        /// 为TextBox设置水印文字
        /// </summary>
        /// <param name="textBox">TextBox</param>
        /// <param name="watermark">水印文字</param>
        public static void SetWatermark(this TextBox textBox, string watermark)
        {
            SendMessage(textBox.Handle, EM_SETCUEBANNER, 0, watermark);
        }
        /// <summary>
        /// 清除水印文字
        /// </summary>
        /// <param name="textBox">TextBox</param>
        public static void ClearWatermark(this TextBox textBox)
        {
            SendMessage(textBox.Handle, EM_SETCUEBANNER, 0, string.Empty);
        }
    }
    #endregion

    #region oew.ini相应的信息，输出文件相应的信息
    /// <summary>
    /// oew.ini相应的信息
    /// </summary>
    public class OewiniClass
    {
        #region 字段
        /// <summary>
        /// 自动按格式路径保存视频截图；
        /// 0 - 手动，弹出对话框让用户选择保存位置；
        /// 1 - 点击视频截图按钮或者快捷键直接保存；
        /// 2 - 每个真缺点截图；
        /// 3 - 每个缺点都截图。
        /// </summary>
        public  CaptureFileAutoSave captureFileAutoSave { get; set; }
        /// <summary>
        /// 保持视频截图起始路径
        /// </summary>
        public string  CapturePath { get; set; }
        /// <summary>
        /// 视频截图格式，0-jpeg，1-bmp，2-png
        /// </summary>
        public CaptureFileType captureFileType { get; set; }
        /// <summary>
        /// 视频截图宽度，像素单位，0表示使用原始视频尺寸
        /// </summary>
        public string CaptureFileWidth { get; set; }
        /// <summary>
        /// 视频截图高度，像素单位，0表示使用原始视频尺寸
        /// </summary>
        public string CaptureFileHeight { get; set; }
        /// <summary>
        /// 移动到达后截图
        /// </summary>
        public string CaptureArrived { get; set; }
        /// <summary>
        /// 到达后延时截图（毫秒）
        /// </summary>
        public string CaptureArriveDelay { get; set; }

        public enum CaptureFileAutoSave: int
        {
            手动 = 0,
            点击视频截图按钮或者快捷键直接保存 = 1,
            每个真缺点截图 = 2,
            每个缺点都截图 = 3
        }

        public enum CaptureFileType : int
        {
            jpg = 0,
            bmp = 1,
            png = 2
        }
        #endregion

        #region 方法
        /// <summary>
        /// 根据.ini获取相应的信息
        /// </summary>
        /// <param name="oewiniClass"></param>
        /// <param name="iniFiles"></param>
        public static void OewiniClassSetting(ref OewiniClass oewiniClass, IniFiles iniFiles)
        {
            oewiniClass = new OewiniClass()
            {
                captureFileAutoSave = (CaptureFileAutoSave)iniFiles.ReadInteger("General", "CaptureFileAutoSave", 3),
                CapturePath = iniFiles.ReadString("General", "CapturePath", string.Empty),
                captureFileType = (CaptureFileType)iniFiles.ReadInteger("General", "CaptureFileType", 0),
                CaptureFileWidth = iniFiles.ReadString("General", "CaptureFileWidth", string.Empty),
                CaptureFileHeight = iniFiles.ReadString("General", "CaptureFileHeight", string.Empty),
                CaptureArrived = iniFiles.ReadString("General", "CaptureArrived", string.Empty),
                CaptureArriveDelay = iniFiles.ReadString("General", "CaptureArriveDelay", string.Empty)
            };
        }
        #endregion
    }

    /// <summary>
    /// D:\Picture信息
    /// </summary>
    public class FileDirectoryClass
    {
        #region 字段
        /// <summary>
        /// 机器名
        /// </summary>
        public string Mach_No { get; set; }
        /// <summary>
        /// 保持视频截图起始路径
        /// </summary>
        public string CapturePath { get; set; }
        /// <summary>
        /// AOI编号
        /// </summary>
        public string Aoi_No { get; set; }
        /// <summary>
        /// 料号
        /// </summary>
        public string Item_No { get; set; }
        /// <summary>
        /// 完整图片路径的目录部分，不含文件名和后缀名
        /// </summary>
        public string FileDirectory { get; set; }
        /// <summary>
        /// 每个板的每一面的每个点的信息
        /// </summary>
        public List<PictureClass> pictures { get; set; } = new List<PictureClass>();
        /// <summary>
        /// 料号文件夹的更改时间
        /// </summary>
        public DateTime file_time = new DateTime();
        #endregion

        #region 方法
        /// <summary>
        /// 获取指定目录文件
        /// </summary>
        /// <param name="fdcs"></param>
        /// <param name="path"></param>
        /// <param name="s_l"></param>
        public static void GetFiles(ref List<FileDirectoryClass> fdcs, ref Exception Ex_me, string path)
        {
            try
            {
                if (path.Length == 0 || !Directory.Exists(path))
                {
                    return;
                }
                else
                {
                    DirectoryInfo dirFolder = new DirectoryInfo(path);
                    //遍历文件夹 AOI编号
                    foreach (var file in dirFolder.GetDirectories())
                    {
                        var aoi_no_file = new DirectoryInfo(file.FullName);
                        if (aoi_no_file.GetDirectories().Length >0)
                        {
                            //遍历文件夹 料号
                            foreach (var item_no_file in aoi_no_file.GetDirectories())
                            {
                                if (item_no_file.GetFiles().Length > 0)
                                {
                                    //遍历文件 层_等级_批号_电路板序号_缺点序号_AOI代码_VRS代码.图片格式
                                    FileDirectoryClass fdc = new FileDirectoryClass();
                                    foreach (var filedirectory in item_no_file.GetFiles())
                                    {
                                        //如果要获取指定扩展名（比如.jpeg）文件
                                        if (filedirectory.Extension.Contains(".jpg") || filedirectory.Extension.Contains(".bmp") || filedirectory.Extension.Contains(".png"))
                                        {
                                            string[] str = filedirectory.Name.Split('_');
                                            if (str.Length == 7)
                                                fdc.pictures.Add(new PictureClass()
                                                {
                                                    Layer = str[0],
                                                    Level = str[1],
                                                    Lot_No = str[2],
                                                    Board_Id = str[3],
                                                    Shortcoming = str[4],
                                                    Aoi_Code = str[5],
                                                    Vrs_Code = str[6].Substring(0, 1),
                                                    FileFullName = filedirectory.FullName,
                                                    FileName = filedirectory.Name
                                                });
                                            else if (str.Length > 7)
                                            {
                                                fdc.pictures.Add(new PictureClass()
                                                {
                                                    Layer = str[0],
                                                    Level = string.Empty,
                                                    Lot_No = string.Empty,
                                                    Board_Id = str[str.Length - 4],
                                                    Shortcoming = str[str.Length - 3],
                                                    Aoi_Code = str[str.Length - 2],
                                                    Vrs_Code = str[str.Length - 1].Substring(0, 1),
                                                    FileFullName = filedirectory.FullName,
                                                    FileName = filedirectory.Name
                                                });
                                            }
                                        }
                                    }
                                    fdc.Mach_No = Environment.MachineName;
                                    fdc.CapturePath = path;
                                    fdc.Aoi_No = aoi_no_file.Name;
                                    fdc.Item_No = item_no_file.Name;
                                    fdc.FileDirectory = item_no_file.FullName;
                                    fdc.file_time = aoi_no_file.LastWriteTime;
                                    fdcs.Add(fdc);
                                }
                                else
                                {
                                    if (Directory.Exists(item_no_file.FullName))
                                        Directory.Delete(item_no_file.FullName, true); //删除空料号文件夹
                                }
                            }
                        }
                        else
                        {
                            if (Directory.Exists(aoi_no_file.FullName))
                                Directory.Delete(aoi_no_file.FullName, true); //删除空AOI编号文件夹
                        }
                    }
                    //排序料号文件夹的更改时间降序和料号降序
                    int i = 0;
                    List<FileDirectoryClass> objv = fdcs.OrderByDescending(e => e.file_time).ThenByDescending(e => e.Item_No).ToList();
                    fdcs.Clear();
                    foreach (var v in objv)
                    {
                        i++;
                        if (i > 20)
                        {
                            if (Directory.Exists(v.FileDirectory))
                                Directory.Delete(v.FileDirectory, true); //删除料号文件夹
                        }
                        else
                        {
                            fdcs.Add(v);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                fdcs = null;
                ex = Ex_me;
            }
        }
        #endregion
    }

    /// <summary>
    /// 每个板的每一面的每个点的信息
    /// </summary>
    public class PictureClass
    {
        #region 字段
        /// <summary>
        /// 层
        /// </summary>
        public string Layer{ get; set; }
        /// <summary>
        /// 级别
        /// </summary>
        public string Level { get; set; }
        /// <summary>
        /// 批号
        /// </summary>
        public string Lot_No { get; set; }
        /// <summary>
        /// 序号
        /// </summary>
        public string Board_Id { get; set; }
        /// <summary>
        /// 缺点
        /// </summary>
        public string Shortcoming { get; set; }
        /// <summary>
        /// 对应Aoi的指定编号
        /// </summary>
        public string Aoi_Code{ get; set; }
        /// <summary>
        /// 对应Vrs的指定编号
        /// </summary>
        public string Vrs_Code { get; set; }
        /// <summary>
        /// 完整文件名
        /// </summary>
        public string FileFullName { get; set; }
        /// <summary>
        /// 文件名
        /// </summary>
        public string FileName { get; set; }
        #endregion
    }

    /// <summary>
    /// 按客户要求的文件格式
    /// </summary>
    public class OutputClass
    {
        #region 字段
        /// <summary>
        /// 机器名
        /// </summary>
        public string mach_no { get; set; }
        /// <summary>
        /// 年
        /// </summary>
        public string year { get; set; }
        /// <summary>
        /// 月
        /// </summary>
        public string month { get; set; }
        /// <summary>
        /// 日
        /// </summary>
        public string day { get; set; }
        /// <summary>
        /// 料号
        /// </summary>
        public string item_no { get; set; }
        /// <summary>
        /// 层
        /// </summary>
        public string layer { get; set; }
        /// <summary>
        /// 序号
        /// </summary>
        public string board_id { get; set; }
        /// <summary>
        /// 共享目录
        /// </summary>
        public string path { get; set; }
        /// <summary>
        /// 完整文件名
        /// </summary>
        public List<string> fullname { get; set; } = new List<string>();
        #endregion

        #region 方法
        /// <summary>
        /// 根据FileDirectoryClass集合获取OutputClass集合
        /// </summary>
        /// <param name="outputs"></param>
        /// <param name="fdcs"></param>
        public static void GetOutput(ref List<OutputClass> outputs, List<FileDirectoryClass> fdcs, string pathstr)
        {
            foreach (var v in fdcs)
            {
                foreach (var a  in v.pictures)
                {
                    var file = new FileInfo(a.FileFullName);
                    var r = outputs.Where(
                        e => e.mach_no == v.Mach_No
                        && e.item_no == v.Item_No
                        && e.layer == a.Layer 
                        && e.board_id == a.Board_Id 
                        && e.year == file.CreationTime.Year.ToString()
                        && e.month == file.CreationTime.Month.ToString()
                        && e.day == file.CreationTime.Day.ToString()
                        ).FirstOrDefault();
                    if (r == null)
                    {
                        OutputClass output = new OutputClass()
                        {
                            mach_no = v.Mach_No,
                            item_no = v.Item_No,
                            layer = a.Layer,
                            board_id = a.Board_Id,
                            year = file.CreationTime.Year.ToString(),
                            month = file.CreationTime.Month.ToString(),
                            day = file.CreationTime.Day.ToString(),
                            path = pathstr + "\\" + v.Mach_No + "\\" + file.CreationTime.Year.ToString() + "\\" + file.CreationTime.Month.ToString() + "\\" + file.CreationTime.Day.ToString() + "\\" + v.Item_No + "\\" + a.Layer + "\\" + a.Board_Id,
                        };
                        output.fullname.Add(a.FileFullName);
                        outputs.Add(output);
                        r = output;
                    }
                    else
                    {
                        if (!r.fullname.Contains(a.FileFullName))
                        {
                            r.fullname.Add(a.FileFullName);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 根据路径，输出文件
        /// </summary>
        /// <param name="outputs"></param>
        /// <param name="pathstr"></param>
        public static void SetOutput(List<OutputClass> outputs, string pathstr)
        {
            if (Directory.Exists(pathstr))
            {
                foreach (var v in outputs)
                {
                    if (!Directory.Exists(v.path))
                    {
                        Directory.CreateDirectory(v.path);
                    }
                    foreach(var a in v.fullname)
                    {
                        var file = new FileInfo(a);
                        if (File.Exists(v.path + "\\" + file.Name))
                        {
                            File.Delete(v.path + "\\" + file.Name);
                        }
                        File.Move(a, v.path + "\\" + file.Name);
                    }
                }
            }
        }
        #endregion
    }
    #endregion

}
