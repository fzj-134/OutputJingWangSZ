﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OutputJingWangSZ
{
    static class Program
    {
        public static Mutex mutex;

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //判断应用程序是否运行
            mutex = new Mutex(true, "OnlyRun");

            if (!mutex.WaitOne(0, false))
            {
                MessageBox.Show("程序已运行", "系统运行", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Application.Exit();
                return;
            }
            else
            {
                Application.Run(new DlgMain());
            }
        }
    }
}
