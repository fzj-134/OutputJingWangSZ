﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Collections.Specialized;
using Generic = System.Collections.Generic;

namespace Report
{
	struct InspectFile
	{
		public String file;
		public String vrs;
		public String server;
		public String job;
		public String layer;
		public String stage;
		public String batch;
		public String day;
	}

	class InspectFiles
	{

		public Queue<InspectFile> files = new Queue<InspectFile>();

		public StringCollection days = new StringCollection();

		public InspectFiles(string root, SortedSet<string> vrses, DateTime start, DateTime end, HashSet<string> outers, bool outer)
		{
			Char[] split = new Char[] { '#' };
			foreach (string vrs in vrses)
			{
				try
				{
					foreach (var part in Directory.EnumerateFiles(root + "\\" + vrs + "\\PCB", "*.csv", SearchOption.TopDirectoryOnly))
					{
						String[] result = part.Split(split, StringSplitOptions.None);
						if (result.Length == 6)
						{
							String day = result[5].Substring(0, 10);
							DateTime filedate = Convert.ToDateTime(day);
							String layer = result[2].ToLower();
							if (start <= filedate && filedate < end && (
								// 外层
								(outer && IsOuterLayer(outers, layer)) ||
								// 内层
								(!outer && !IsOuterLayer(outers, layer))))
							{
								InspectFile insf = new InspectFile();
								insf.file = part;

								insf.vrs = vrs;

								int m = result[0].LastIndexOf('\\');
								insf.server = m != -1 ? result[0].Substring(m + 1) : "";
								insf.job = result[1];
								insf.layer = result[2];
								insf.stage = result[3];
								insf.batch = result[4];
								insf.day = day;

								files.Enqueue(insf);

								days.Add(day);
							}
						}
					}
				}
				catch
				{ }
			}
		}

		public InspectFiles(string root, string vrs, DateTime start, DateTime end, HashSet<string> outers, bool outer)
		{
			Char[] split = new Char[] { '#' };
			try
			{
				foreach (var part in Directory.EnumerateFiles(root + "\\" + vrs + "\\PCB", "*.csv", SearchOption.TopDirectoryOnly))
				{
					String[] result = part.Split(split, StringSplitOptions.None);
					if (result.Length == 6)
					{
						String day = result[5].Substring(0, 10);
						DateTime filedate = Convert.ToDateTime(day);
						String layer = result[2].ToLower();
						if (start <= filedate && filedate < end && (
							// 外层
							(outer && IsOuterLayer(outers, layer)) ||
							// 内层
							(!outer && !IsOuterLayer(outers, layer))))
						{
							InspectFile insf = new InspectFile();
							insf.file = part;

							insf.vrs = vrs;

							int m = result[0].LastIndexOf('\\');
							insf.server = m != -1 ? result[0].Substring(m + 1) : "";
							insf.job = result[1];
							insf.layer = result[2];
							insf.stage = result[3];
							insf.batch = result[4];
							insf.day = day;

							files.Enqueue(insf);

							days.Add(day);
						}
					}
				}
			}
			catch
			{ }
		}

		public InspectFiles(string root, string vrs, string lot)
		{
			Char[] split = new Char[] { '#' };
			try
			{
				foreach (var part in Directory.EnumerateFiles(root + "\\" + vrs + "\\PCB", "*.csv", SearchOption.TopDirectoryOnly))
				{
					String[] result = part.Split(split, StringSplitOptions.None);
					if (result.Length == 6 && lot == result[4])
					{
						String day = result[5].Substring(0, 10);
						days.Add(day);

						InspectFile insf = new InspectFile();
						insf.file = part;
						insf.vrs = vrs;
						int m = result[0].LastIndexOf('\\');
						insf.server = m != -1 ? result[0].Substring(m + 1) : "";
						insf.job = result[1];
						insf.layer = result[2];
						insf.stage = result[3];
						insf.batch = result[4];
						insf.day = day;
						files.Enqueue(insf);
					}
				}
			}
			catch
			{ }
		}

		public bool IsOuterLayer(HashSet<string> outers, string layer)
		{
			foreach(string outer in outers)
				if (outer.Length > 0 && outer.Length <= layer.Length && outer == layer.Substring(0, outer.Length))
					return true;
			return false;
		}
	}
}
