﻿namespace OutputJingWangSZ
{
    partial class DlgMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DlgMain));
            this.lblVersion2 = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.gbAlarm = new System.Windows.Forms.GroupBox();
            this.buttondelect = new System.Windows.Forms.Button();
            this.textBox_hint = new System.Windows.Forms.TextBox();
            this.dataGridView_pic = new System.Windows.Forms.DataGridView();
            this.Column_Choice = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Item_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_AOI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_Eff = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonChoice = new System.Windows.Forms.Button();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.textBoxpath = new System.Windows.Forms.TextBox();
            this.buttonpath = new System.Windows.Forms.Button();
            this.fbDlg1 = new System.Windows.Forms.FolderBrowserDialog();
            this.NotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.ContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.显示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gbAlarm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_pic)).BeginInit();
            this.ContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblVersion2
            // 
            this.lblVersion2.AutoSize = true;
            this.lblVersion2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblVersion2.Location = new System.Drawing.Point(86, 10);
            this.lblVersion2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVersion2.Name = "lblVersion2";
            this.lblVersion2.Size = new System.Drawing.Size(98, 14);
            this.lblVersion2.TabIndex = 5;
            this.lblVersion2.Text = "00.00.00.0000";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblVersion.Location = new System.Drawing.Point(14, 10);
            this.lblVersion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(56, 14);
            this.lblVersion.TabIndex = 4;
            this.lblVersion.Text = "版本号:";
            // 
            // gbAlarm
            // 
            this.gbAlarm.Controls.Add(this.buttondelect);
            this.gbAlarm.Controls.Add(this.textBox_hint);
            this.gbAlarm.Controls.Add(this.dataGridView_pic);
            this.gbAlarm.Controls.Add(this.buttonChoice);
            this.gbAlarm.Controls.Add(this.buttonupdate);
            this.gbAlarm.Controls.Add(this.textBoxpath);
            this.gbAlarm.Controls.Add(this.buttonpath);
            this.gbAlarm.Location = new System.Drawing.Point(13, 28);
            this.gbAlarm.Margin = new System.Windows.Forms.Padding(4);
            this.gbAlarm.Name = "gbAlarm";
            this.gbAlarm.Padding = new System.Windows.Forms.Padding(4);
            this.gbAlarm.Size = new System.Drawing.Size(806, 649);
            this.gbAlarm.TabIndex = 19;
            this.gbAlarm.TabStop = false;
            this.gbAlarm.Text = "操作：";
            // 
            // buttondelect
            // 
            this.buttondelect.Location = new System.Drawing.Point(169, 24);
            this.buttondelect.Name = "buttondelect";
            this.buttondelect.Size = new System.Drawing.Size(75, 23);
            this.buttondelect.TabIndex = 25;
            this.buttondelect.Text = "删除";
            this.buttondelect.UseVisualStyleBackColor = true;
            this.buttondelect.Click += new System.EventHandler(this.buttondelect_Click);
            // 
            // textBox_hint
            // 
            this.textBox_hint.Location = new System.Drawing.Point(4, 546);
            this.textBox_hint.Multiline = true;
            this.textBox_hint.Name = "textBox_hint";
            this.textBox_hint.ReadOnly = true;
            this.textBox_hint.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_hint.Size = new System.Drawing.Size(794, 96);
            this.textBox_hint.TabIndex = 24;
            this.textBox_hint.Text = "暂时没有提示！";
            // 
            // dataGridView_pic
            // 
            this.dataGridView_pic.AllowUserToAddRows = false;
            this.dataGridView_pic.AllowUserToDeleteRows = false;
            this.dataGridView_pic.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_pic.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column_Choice,
            this.Column_Item_no,
            this.Column_AOI,
            this.Column_Eff,
            this.Column_time});
            this.dataGridView_pic.Location = new System.Drawing.Point(4, 53);
            this.dataGridView_pic.Name = "dataGridView_pic";
            this.dataGridView_pic.ReadOnly = true;
            this.dataGridView_pic.RowTemplate.Height = 23;
            this.dataGridView_pic.Size = new System.Drawing.Size(794, 484);
            this.dataGridView_pic.TabIndex = 23;
            this.dataGridView_pic.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_pic_CellClick);
            // 
            // Column_Choice
            // 
            this.Column_Choice.HeaderText = "是否上传";
            this.Column_Choice.Name = "Column_Choice";
            this.Column_Choice.ReadOnly = true;
            // 
            // Column_Item_no
            // 
            this.Column_Item_no.HeaderText = "料号";
            this.Column_Item_no.Name = "Column_Item_no";
            this.Column_Item_no.ReadOnly = true;
            this.Column_Item_no.Width = 200;
            // 
            // Column_AOI
            // 
            this.Column_AOI.HeaderText = "AOI名称";
            this.Column_AOI.Name = "Column_AOI";
            this.Column_AOI.ReadOnly = true;
            this.Column_AOI.Width = 200;
            // 
            // Column_Eff
            // 
            this.Column_Eff.HeaderText = "是否有效";
            this.Column_Eff.Name = "Column_Eff";
            this.Column_Eff.ReadOnly = true;
            // 
            // Column_time
            // 
            this.Column_time.HeaderText = "时间";
            this.Column_time.Name = "Column_time";
            this.Column_time.ReadOnly = true;
            this.Column_time.Width = 150;
            // 
            // buttonChoice
            // 
            this.buttonChoice.Location = new System.Drawing.Point(88, 24);
            this.buttonChoice.Name = "buttonChoice";
            this.buttonChoice.Size = new System.Drawing.Size(75, 23);
            this.buttonChoice.TabIndex = 22;
            this.buttonChoice.Text = "刷新";
            this.buttonChoice.UseVisualStyleBackColor = true;
            this.buttonChoice.Click += new System.EventHandler(this.buttonChoice_Click);
            // 
            // buttonupdate
            // 
            this.buttonupdate.Location = new System.Drawing.Point(7, 24);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(75, 23);
            this.buttonupdate.TabIndex = 2;
            this.buttonupdate.Text = "上传";
            this.buttonupdate.UseVisualStyleBackColor = true;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            // 
            // textBoxpath
            // 
            this.textBoxpath.Location = new System.Drawing.Point(331, 24);
            this.textBoxpath.Name = "textBoxpath";
            this.textBoxpath.ReadOnly = true;
            this.textBoxpath.Size = new System.Drawing.Size(467, 23);
            this.textBoxpath.TabIndex = 20;
            // 
            // buttonpath
            // 
            this.buttonpath.Location = new System.Drawing.Point(250, 24);
            this.buttonpath.Name = "buttonpath";
            this.buttonpath.Size = new System.Drawing.Size(75, 23);
            this.buttonpath.TabIndex = 21;
            this.buttonpath.Text = "浏览...";
            this.buttonpath.UseVisualStyleBackColor = true;
            this.buttonpath.Click += new System.EventHandler(this.buttonpath_Click);
            // 
            // NotifyIcon
            // 
            this.NotifyIcon.ContextMenuStrip = this.ContextMenuStrip;
            this.NotifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("NotifyIcon.Icon")));
            this.NotifyIcon.Text = "NotifyIcon";
            this.NotifyIcon.Visible = true;
            this.NotifyIcon.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
            // 
            // ContextMenuStrip
            // 
            this.ContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.显示ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.ContextMenuStrip.Name = "ContextMenuStrip";
            this.ContextMenuStrip.Size = new System.Drawing.Size(101, 48);
            // 
            // 显示ToolStripMenuItem
            // 
            this.显示ToolStripMenuItem.Name = "显示ToolStripMenuItem";
            this.显示ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.显示ToolStripMenuItem.Text = "显示";
            this.显示ToolStripMenuItem.Click += new System.EventHandler(this.显示ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // DlgMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 679);
            this.Controls.Add(this.gbAlarm);
            this.Controls.Add(this.lblVersion2);
            this.Controls.Add(this.lblVersion);
            this.Font = new System.Drawing.Font("宋体", 10.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "DlgMain";
            this.Text = "图片归档软件";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DlgMain_FormClosing);
            this.SizeChanged += new System.EventHandler(this.DlgMain_SizeChanged);
            this.gbAlarm.ResumeLayout(false);
            this.gbAlarm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_pic)).EndInit();
            this.ContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVersion2;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.GroupBox gbAlarm;
        private System.Windows.Forms.TextBox textBoxpath;
        private System.Windows.Forms.Button buttonpath;
        private System.Windows.Forms.FolderBrowserDialog fbDlg1;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.NotifyIcon NotifyIcon;
        private new System.Windows.Forms.ContextMenuStrip ContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem 显示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.Button buttonChoice;
        private System.Windows.Forms.DataGridView dataGridView_pic;
        private System.Windows.Forms.TextBox textBox_hint;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Choice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_Item_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_AOI;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_Eff;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_time;
        private System.Windows.Forms.Button buttondelect;
    }
}

